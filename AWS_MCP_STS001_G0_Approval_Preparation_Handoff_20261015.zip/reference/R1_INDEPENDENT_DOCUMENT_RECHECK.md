# AWS MCP STS-001 Investigation B — R1 Independent Limited Document Recheck

- **Review date:** 2026-10-15 (JST)
- **Reviewer:** GPT-6, independent static document reviewer (no role as plan author, AWS executor or approver)
- **Decision:** **ACCEPTED_FOR_P0_APPROVAL_CONSIDERATION** (document-only)
- **Plan state:** `PLAN_PREPARED_PENDING_EXECUTION_APPROVAL` (unchanged)
- **Operational authorization:** NONE. G0–G5, G1b and G5-release remain separately gated and `NOT_AUTHORIZED`.
- **AWS environment / credential-provider / storage / request-path validation:** NOT PERFORMED / NOT VERIFIED.
- **Gate STS-001:** `NOT VERIFIED` (unchanged).

## 1. Reviewed local documents and independent identity checks

| Item | R0 | R1 | Result |
| --- | --- | --- | --- |
| Execution plan | 861 lines, SHA-256 `11ce1cae1fc7f209f472c3e9ba0b696019ba1b64fe142ab72abd2822072fe1f9` | 1009 lines, SHA-256 `15a9adad32011a6f1f660875d877c25092afc8eaa38a8c6a4b2486c1c451b9b1` | MATCH |
| Decision record | 88 lines, SHA-256 `2395a5e388f2e40bce459482a616459d2614659fb74f202326f5e69f2b69a363` | 100 lines, SHA-256 `a0d9d175e1c280bee1eab856783bf356c5cde33dd2383fc591395f68c79771c6` | MATCH |
| R1 change register | — | SHA-256 `88b46081efe54c40175b610ec98019642e941acd543960b05d4376a3fa3bf2c8` | Direct file digest recorded |

R0 and R1 were independently compared using the actual five local files, not reconstructed solely from the R1 change author's assertions. The line-based unified diff with one context line produces **25 plan hunks and 4 decision-record hunks**, matching all 29 location tuples in the R1 change register. Both original and revised documents were loaded for full-file comparison. The original **candidate API allowlist table and quantitative budget table are byte-for-byte unchanged**. Stages P0–P5, 12 tasks, F1–F4, nine planned deliverables and the 0/2/60/200/600/0 = **862** request ceilings are maintained. No added AWS API, broader region allowance, wrapper/Broker implementation, source-credential authorization or automatic gate grant was identified in the edits.

The change register's optional *extracted-table digest* calculation does not specify a reproducible extraction/serialization procedure. This review instead independently compares the exact original and revised table text; its byte-exact result does not depend on those supplementary digests.

## 2. Original four findings: disposition

### IB-PLAN-001 — HIGH — **DOCUMENT_CORRECTED; OPERATIONAL_BOUNDARY_UNVERIFIED**

**R1 plan evidence:** L225–249, L633, L763–788, L717–721. Original AWS config and environment may only be examined inside a distinct human-controlled trusted boundary; the AI may consume approved sanitized candidate metadata only. The original AWS config cannot be mounted/read from the AI environment. If neither an existing trusted extractor nor independently approved minimized input is available, use `P0_CONFIG_DISCOVERY_BLOCKED`. The plan explicitly rejects synthetic parser tests as proof of production isolation.

**Review outcome:** Meets the prior narrowly specified textual correction. No demonstration of a trusted extractor, runtime permissions or practical isolation was submitted; this is a G0/P0 operational prerequisite, not a finding closure for actual credential security.

### IB-PLAN-002 — HIGH — **DOCUMENT_CORRECTED; PRE_G1_GO_NOT_ESTABLISHED**

**R1 plan evidence:** L173–174, L203–207, L339–356, L412–449, L602–603, L655, L673, L774–785, L796–799. Both Mode A and human-operated Mode B require a signed or equivalently authenticated attestation for the actual selected mode, tied to tool/runtime and configuration digests, source-provider category, prevention of refresh/auto-assume, endpoint/proxy/redirect enforcement, physical HTTP attempt counting, network-disabled failure fixtures and configuration-equivalence attestation. Unknown/unstoppable issuance or unobservable physical attempts are `NO_GO`; **even `sts:GetCallerIdentity` is prohibited** until G1 and this evidence exist.

**Review outcome:** Meets the required pre-G1 textual correction without assuming that CLI settings, simulated fixtures or custodian statements alone establish an implemented control. No actual provider or request path was inspected.

### IB-PLAN-003 — MEDIUM — **DOCUMENT_CORRECTED; G0_APPROVER_PENDING**

**R1 plan evidence:** L173, L185–190, L192–207, L652–653, L668–675. R1 adopts exactly one of the two alternatives proposed in R0 review: OD-02 applies to local **G0** as well as later AWS gates. The same verified approver must have documented local-scope authority, sign the bounded G0 operation/input/extractor/storage/lifecycle scope, and not derive approval from operator consent or an agent-authored decision record.

**Review outcome:** Removes the ambiguity in the approval schema. The name, authority and separate attributable grant have **not** been established by the revised text.

### IB-PLAN-004 — MEDIUM — **DOCUMENT_CORRECTED; LIFECYCLE_APPROVAL_PENDING**

**R1 plan evidence:** L465–485, L538–585, L604–605, L660–661, L668–675, L742–761, L933–953. OD-09/10 and a G0-bound per-class lifecycle plan must exist **before any operational case-owned file write**, not merely the first restricted raw AWS capture. The scheme distinguishes review deadline from actual expiry, required pre-expiry escalation, prior case-limited deletion authority, legal-hold exception, deletion failure as `RETENTION_BREACH`, and independent handling of originals, aliases/salts, transient files, QA/audit, local share copies and recipient copies. It does not authorize broad file deletion or delete audit records by an AI agent.

**Review outcome:** Resolves the previously identified textual conflict between expiry and later deletion permission. No real custodian approval, filesystem or retention mechanism was tested or granted.

## 3. Gate-ready documentation vs operational gate decisions

| Boundary | Mandatory owner actions before its execution | Status now |
| --- | --- | --- |
| **Before G0 / P0 local execution** | OD-01 identified operator; OD-02 verified approver with G0 local authority and separately attributable narrow G0 grant; OD-08 initial safe extraction/sanitized-metadata mode; OD-09 approved canonical storage, custodian, isolation/sync exclusions; OD-10 per-class retention/review/escalation plus independently granted standing deletion authority before any case write | **ALL PENDING** |
| **During separately approved P0; before G1 / any AWS request** | OD-04 effective source/provider validity + mode-specific signed GO for provider and physical request path; OD-08 full selected-mode proof; OD-03 exact STS/IAM endpoint and Region/signing details; OD-11 approved per-API/physical-attempt/pagination/cost caps; fresh independently attributable G1 grant | **NOT VERIFIED / NOT AUTHORIZED** |
| **After P1; before G2–G4** | Human G1b adoption of actually observed source principal, then distinct G2/G3/G4 scoped approvals and relevant OD decisions | **NOT AUTHORIZED** |
| **Before release and independent raw review** | G5 local processing; OD-14 recipient/reviewer confidentiality decisions and separate G5-release; reviewer raw-original entitlement as applicable | **NOT AUTHORIZED** |

Approval of G0, if later explicitly granted, authorizes only its precise local scope; it does not authorize checking current credential values, invoking STS/AWS, performing P1–P5 or deleting files without a separate pre-existing attributable authorization. The R1 correction itself is not a permission to perform G0.

## 4. Remaining scope, F-004/F-006 and budget

- The allowlist and proposed budget are unchanged. **862 is an unapproved cumulative stop ceiling, not an empirically validated capacity or cost estimate.** The physical-request enforcement/visibility proof and later OD-11 numerical budget remain mandatory before G1 and every respective later AWS stage.
- F-004: pre/post ReadOnlyAccess policy metadata and document hashes can support a *point-in-time* observation; R1 L677–680 and L843–845 explicitly reject permanent managed-policy pinning or future drift prevention. Independent baseline approval and any future runtime comparison remain distinct.
- F-006: the approved service/path subsets can produce bounded resource-policy/ACL/grant risk evidence; all excluded paths, denied operations, incomplete denominators and unavailable restricted originals remain explicit. Nothing permits a global no-write claim or Finding Closure.
- Operational isolation, human attestation authenticity, enforcement boundary, secrets containment, data protection, actual identity matching and evidence integrity remain **NOT VERIFIED**, and were not assessed via AWS requests in this review.

## 5. Final adjudication and necessary next action

**ACCEPTED_FOR_P0_APPROVAL_CONSIDERATION** — The **four R0 document findings have been corrected at the static-text level**; no new R1 document defect requires an R2 rewrite. This supersedes `CONDITIONAL_ACCEPT` for *document acceptability only*. It does **not** classify G0 as ready-to-execute: OD-01/02/08/09/10 and a trusted human-signed, digest-bound, narrow G0 approval still need to be provided and independently validated. No IAM/AWS, config/credentials, GitHub, Broker or local case execution was performed or authorized.

The appropriate next actor is the **human authorization/custody side**, supported by a planning-only AI for preparing a proposed G0 approval packet. An AI executor must stop until the named human approves the exact G0 scope through a trusted channel. Gate STS-001, F-004, F-006, role reuse and future G1–G5 permissions remain unchanged.
