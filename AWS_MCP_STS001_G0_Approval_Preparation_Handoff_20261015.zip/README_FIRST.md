# READ FIRST — planning-only supplementary bundle

This handoff ZIP contains only documentation, not AWS credentials, SDK execution material or authority to perform G0/P0. All AWS operations, authentication/cache/config access and GitHub writes are prohibited by 00_AGENT_PROMPT.md.

Source of truth is the merged R1 repository file content at the expected hashes. The reference files here are attached copies for agents without repository access; they do not prove GitHub state or human approval. If repository files are available and hashes diverge, stop and request authoritative reconciliation.

The external signed human approval of exact G0 scope remains required before any P0 local execution. Do not interpret document review acceptance as such approval.
