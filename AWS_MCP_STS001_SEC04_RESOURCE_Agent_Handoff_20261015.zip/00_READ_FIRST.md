# AWS MCP STS-001 — SEC04-RESOURCE Evidence Acquisition / READ FIRST

**作業パケット作成日:** 2026-10-15 JST  
**GitHub:** `yohi/chatgpt-mcp-tunnel` / `feat/aws-broad-iam-read-api-tools`  
**固定 Commit:** `05f4b92e7ff2de76dc79cf8d5dc9f563a03af209`  
**対象 AWS Account:** `168975706502`  
**既存 IAM Role 候補:** `arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role`  
**期待 RoleId:** `AROASOV54VGDAC4S2255I`  
**入力証跡:** `AWS_MCP_STS001_Broker_Security_Contract_Draft_20261014(1).md`（未承認）、R2報告、SAR原本検証報告（いずれも読み取り用）

## 目的と立場

ローカルAIエージェントは、**AWS権限のあるローカル環境で読み取り専用の証跡を取得する Acquisition Operator** として行動する。安全性を保証するレビュアー、Role Owner、Requirements Owner、Gate承認者にはならない。

対象は **F-004（ReadOnlyAccess版とドリフト）／F-006（resource-based permission pathways）／共有 ECS ロールの利用実態・非干渉の証跡**。F-003のAPI契約確定、F-005のSTS packed limit実験、Broker実装、SEC01 Runtime隔離は本作業に含めない。

**Gate STS-001: NOT VERIFIED。既存ロール再利用は未承認。GitHubへの書き込み、本番有効化、AWS IAM/STSセッション発行・変更は禁止。**

## 使用順序

1. `01_FULL_WORK_CONTRACT.md` を全文読む。
2. `02_AGENT_EXECUTION_PROMPT.md` をローカルエージェントに渡す。
3. `03_EVIDENCE_REQUIREMENTS.csv` で必要証跡と完了条件を確認する。
4. `04_ALLOWED_OPERATIONS.csv` の許可候補を人間がレビューする。**列挙された全APIへの包括的実行許可を意味しない**。
5. `05_COMMAND_PLAYBOOK.md` を参照し、アカウント/ロール同定を先行。Scopeごとに人間の許可を得る。
6. `06_OUTPUT_AND_REVIEW_CONTRACT.md` に従い機密原本と共有用要約を分離する。

## 緊急停止

Account/RoleId不一致、利用者の権限/対象未確認、認証情報漏えいの疑い、予期しないAPIリクエスト、スコープ逸脱、意図しない実環境変更があれば停止し報告。**失敗した操作を強い権限や別のプロファイル、別のSTSセッションに切り替えて再実行しない。**

## 完了の意味

成果物は `CAPTURED_PENDING_INDEPENDENT_REVIEW` として提出する。AWS Policy 取得成功は、包括的な書込禁止証明でもFinding Closureでもない。権限不足、未対応Region/サービス、列挙未完は必ず `UNKNOWN` / `NOT_COVERED` として残す。
