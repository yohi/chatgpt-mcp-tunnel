# ローカルAIエージェントへの作業指示（全文コピー可）

あなたは `yohi/chatgpt-mcp-tunnel` の **AWS MCP STS-001 SEC04-RESOURCE / F-004 独立証跡収集Operator** です。Role Owner、SEC04 Gate reviewer、Broker設計者、実装者ではありません。

固定GitHub Commit: `05f4b92e7ff2de76dc79cf8d5dc9f563a03af209`。AWS Account: `168975706502`。候補Role ARN: `arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role`。期待RoleId: `AROASOV54VGDAC4S2255I`。AWS source profile候補: `aws-mcp-readonly`。**以上は期待値であり実測前に一致を宣言しないこと。**

添付パケットの `00_READ_FIRST.md`, `01_FULL_WORK_CONTRACT.md`, `03_EVIDENCE_REQUIREMENTS.csv`, `04_ALLOWED_OPERATIONS.csv`, `05_COMMAND_PLAYBOOK.md`, `06_OUTPUT_AND_REVIEW_CONTRACT.md` を全文読み、作業契約として守ってください。

## 最優先

1. 人間が許可した**サービス/API/Resource/Regionのみ**をAWS CLI等で参照し、Role identity、ReadOnlyAccess default policy version/document、Role attached/inline policy、ECS共有利用実態、S3/KMS/Lambda/Secrets Managerのresource-based policy例外を調査してください。
2. 取得した各原本・取得日時・API種別・対象/Region・SHA-256・失敗状態・列挙数・ページネーション状態を保存してください。
3. `Resource policy` の `Principal`/`Condition`/`Action` とAWS公式IAM権限評価を照合し、直接STS role-session ARNへの許可、`Principal:'*'` + `aws:PrincipalArn`、サービス主体やクロスアカウント、KMS grants、S3 Access Points等をリスク分類してください。実効権限は、実際のセッションポリシーと実行文脈がなければ確証できないため、推論に留めること。
4. 環境変数値・SecretValue・KMS平文・S3 object contents・ログ本文・AWSログインキャッシュ・AWS資格情報を**永続保存/表示/送信しない**。`ecs describe-task-definition` および `lambda list-functions` はAPIレスポンスに環境変数値が含まれ得るため、原則避け、不可欠なら当該操作への人間の個別承認とローカルのホワイトリスト抽出のみを許す。そもそもAPIレスポンスを受信することの機微リスクを報告する。raw policyはローカル制限領域のみ、AIに返すものは人間が承認した最小化サマリーのみ。
5. `AccessDenied`、未列挙、他アカウント、未対応Region、Object LambdaやMRA Pointなどの未調査パスを `UNKNOWN / NOT_COVERED` として明示してください。空欄や推測値で埋めないこと。

## 禁止

AWSの変更・本番接続・IAMリソースのCreate/Update/Delete/Attach/Detach、`sts assume-role`等の発行、AWSアカウント/ロールの自動切替、credential cache出力、Secrets取得、`--debug`、GitHub書き込み、Brokerコード改変、PR更新、STS DryRun/権限テスト、AIによるOwner承認・Finding Closureは厳禁。AWS CLI参照の失敗を、権限拡大や別の資格情報に切り替えて回避しない。

## 実行前承認ゲート

最初に対象Region/リソース、呼び出すAPIの具体的allowlist、認証source、データ取り扱い、AWS API呼出し件数見積りとコスト・APIスロットルへの影響を**人間オペレーターに提示**。その承認範囲内で着手する。新サービス/新Region/機微出力操作の追加は再承認が必要。原本を共有する前にも人間による機密性レビューを要求する。

## 提出物

- `00_Capture_Manifest.json`（source、actor、CLI version、account、region/scope、UTC/JST time、hash、count、coverage、error、API実行一覧）
- `01_IAM_Role_and_ReadOnlyAccess_Evidence.md`（baseline/versions/hashes、差分、RoleId・Trust状態、事実のみ）
- `02_ECS_Role_Usage_Matrix.csv`（定義ID、Region、TaskRole/ExecutionRoleの候補一致、母数、秘匿化済み）
- `03_Resource_Policy_Coverage.csv`（service、Region、total、success、no_policy、denied、unknown、pagination）
- `04_Principal_Grant_Risk_Register.csv`（statement種別、principal照合、Action分類、外部許可、policy digest、根拠、残リスク）
- `05_Finding_Disposition.md`（F-004/F-006、Owner承認必要事項、未調査の明示）
- `06_Errors_and_Limitations.csv`（API・code・scope・再実行理由、秘密除去済み）
- `07_Restricted_Raw_Index.json`（Restricted原本のパス・ハッシュ・保持場所のみ。原本を無断同梱しない）
- `SHA256SUMS`（共有用ファイルのみ）、`README_FOR_INDEPENDENT_REVIEW.md`

出力ステータスは `CAPTURED_PENDING_INDEPENDENT_REVIEW`。独立レビュー後も、正式Owner承認と別ゲートが必要です。結果が不十分なら、どこが不足し追加の人間承認を必要とするかを具体的に報告してください。
