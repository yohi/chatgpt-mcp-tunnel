# SEC04-RESOURCE — Output, Hash, Security & Independent Review Contract

## 1. 二層の証跡

**Restricted raw (local only)**
- IAM Role trust, AWS managed/attached policy documents、S3/KMS/Lambda/Secrets resource policy/ACL、KMS grantsの完全な返却データ。`0700`ディレクトリ、`0600`ファイル、明示的保存期限、秘匿情報管理者のみアクセス。
- AWS source login cache、環境変数中の資格情報、AWS CLI credentials、STS Token、S3 object value、Secret Value、KMS plaintext、ECS container env valuesは**そもそも証跡に含めない**。
- 採取1件ごとの生バイト列 SHA-256、取得UTC、実行オペレーション、対象ID、Region、最小CLI version、実行結果、ファイルパス、文字コード、パース可否を記録。AWSレスポンスの全生バイト保存が許可されない場合は`RESTRICTED_METADATA_ONLY`。

**Approved-share (reviewerへの引き渡し用)**
- Policyは人間の安全性審査を経た最小構造サマリーのみ。Principalを一律に削除するとrole/session照合の独立再検証が不能になるため、`PrincipalType`, `AccountScope`, `MatchesTargetRoleArn`, `MatchesRoleId`, `MatchesSessionArnPattern`, `UsesWildcardPrincipalArn`, `ActionWritePotential`, `ConditionClasses`, `RawPolicySHA256`などを構造化して残す。
- 共有不可フィールドは仮名化・固定ラベル化し、同一値の整合性を保つ。Saltや秘密値自体は共有しない。
- ハッシュのみではStatementの正しさを独立検証できない。機微原本を独立レビュアーに渡せないとき、その項目は `INDEPENDENT_REVIEW_RESTRICTED` とし、アクセス権のある別レビュアーに原本チェックを依頼。

## 2. Required top-level manifest schema（例）

```json
{
  "case_id": "AWS-MCP-STS001-SEC04-RESOURCE",
  "status": "CAPTURED_PENDING_INDEPENDENT_REVIEW",
  "acquisition_utc_start": null,
  "acquisition_utc_end": null,
  "operator": "LOCAL_AGENT_UNDER_HUMAN_APPROVAL",
  "authorized_scope_id": null,
  "aws_account_expected": "168975706502",
  "aws_account_observed": null,
  "role_arn_expected": "arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role",
  "role_id_expected": "AROASOV54VGDAC4S2255I",
  "role_id_observed": null,
  "cli_version": null,
  "regions_approved": [],
  "regions_completed": [],
  "operations_approved": [],
  "operations_invoked": [],
  "source_records": [],
  "coverage": [],
  "failures": [],
  "explicit_out_of_scope": [],
  "approval": "NONE_FOR_ROLE_REUSE_OR_IMPLEMENTATION"
}
```

Each `source_records[]`: `service`, `operation`, `resource_locator_or_alias`, `region`, `observed_utc`, `raw_restricted_sha256` (if captured), `share_artifact_sha256`, `result_state` (`SUCCESS`, `NO_POLICY`, `ACCESS_DENIED`, `NOT_SUPPORTED`, `UNKNOWN`, `FAILED`), `error_code`, `pagination_complete`, `sensitivity_tier`.

## 3. Finding adjudication boundary

- `F-004`: `GetPolicy`前後のVersionID + `GetPolicyVersion`取得SHA + Role添付現況 + approval baselineの有無。承認済みbaselineが無ければ「将来のドリフト検出機構が設計・実装された」とは言わない。
- `F-006`: 資源母数/Regionカバレッジと具体的Statement解析が必要。部分取得をGlobal Safeに拡張しない。原本検証できないものはレビュー制限を明記。
- `F-003`: SAR原本が14サービス分固定済みだが Tool/API requirementが未確定。Bの取得から action catalog正式承認を推論しない。
- `F-005`: STS packed size実発行試験は行っていない。変化なし。
- `OWNER`: ECS共有ロール再利用の正式なOwner承認が必要。Operator報告はその代用にならない。
- `SEC04-BOUNDARY`: Brokerが source 管理者認証情報を保持する設計境界は本調査では解消できない。

## 4. 独立再審査への要求

独立レビュアー（このOperatorと別）は、(a) 共有可能な原本のハッシュ一致、(b) 事前承認API allowlist逸脱有無、(c) account/role identifier、(d) versionドリフト/Resource Policy例外抽出、(e) 分母の完全性、(f) 機密原本にアクセスできなかった項目、(g) FindingのClose不可範囲を点検。技術調査の受理と正式採用決裁を分離する。

## 5. ZIP内SHA256SUMS

公開パケットまたは後続のApproved-share成果物では、各ファイルの SHA-256 と外側ZIP SHA-256を記録する。ただし、**Restricted rawや資格情報を無断でまとめてZIP化しない**。
