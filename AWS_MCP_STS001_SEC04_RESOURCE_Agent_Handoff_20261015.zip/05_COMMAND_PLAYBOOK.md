# SEC04-RESOURCE — Restricted AWS CLI Command Playbook

**このファイルは作業例であり、包括的な実行許可ではありません。** 記載コマンドは対象リソース/Region/APIを人間が承認後、AWSログインsourceにアクセスできるローカル環境でのみ実行する。**例の出力はAIチャットや共有ログに貼り付けない。**

## Shell準備（zshのzinitトラブル回避）

ターミナルがzshの場合は `set -u` をzshに直接有効化せず、作業は`bash`専用シェルで実施。`set -x`は絶対禁止。`AWS_PAGER` を無効化する。

```bash
# 使用前に人間が承認したことを確認
bash <<'BASH'
set -euo pipefail
umask 077
export AWS_PAGER=""
export AWS_PROFILE="aws-mcp-readonly"
export AWS_DEFAULT_OUTPUT="json"
export AWS_EC2_METADATA_DISABLED=true

account_expected="168975706502"
role_arn="arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role"
role_name="scs2-stg-ecs-tasks-role"
role_id_expected="AROASOV54VGDAC4S2255I"

# 事前承認済みの場合だけ実行。結果は画面に出さず、スコープ限定の検証に使用。
caller_json=$(aws sts get-caller-identity --no-cli-pager --output json)
actual_account=$(printf '%s' "$caller_json" | python3 -c 'import json,sys;print(json.load(sys.stdin)["Account"])')
if [[ "$actual_account" != "$account_expected" ]]; then
  echo "STOP_ACCOUNT_MISMATCH" >&2
  exit 2
fi

# IAM Roleの属性を最低限だけ抽出。Trust policyの原本出力はここでは保存しない。
role_json=$(aws iam get-role --role-name "$role_name" --no-cli-pager --output json)
printf '%s' "$role_json" | python3 -c '
import json,sys
r=json.load(sys.stdin)["Role"]
assert r["Arn"]=="arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role"
assert r["RoleId"]=="AROASOV54VGDAC4S2255I"
print("ACCOUNT_AND_ROLE_IDENTITY_MATCH",r["MaxSessionDuration"],"seconds")
'
BASH
```

**重要:** シェル変数中の`caller_json`/`role_json`は実行プロセス内だけで保持し、`env`, `set`, `declare -p`, `set -x`, `history`等で表示しない。シェル終了時に破棄される。上記はあくまでP1のpreflightで、Role trust原本保存・ReadOnlyAccess原本取得・Resource全件取得はまだ実施しない。

## IAM: 承認済みRead-Only候補

以下は担当AIが関数化し、**原本をRestricted領域に保存、共有資料はダイジェストと最小項目のみ**生成する。ターミナルに生データを印字しない。全コマンドに `--no-cli-pager --output json --profile aws-mcp-readonly` を付与すること。失敗時はAPI/対象/Regionとエラーコードを機微情報を除いて記録。

```text
aws iam get-role --role-name scs2-stg-ecs-tasks-role
aws iam list-attached-role-policies --role-name scs2-stg-ecs-tasks-role
aws iam list-role-policies --role-name scs2-stg-ecs-tasks-role
aws iam get-role-policy --role-name scs2-stg-ecs-tasks-role --policy-name <DISCOVERED_NAME>
aws iam get-policy --policy-arn arn:aws:iam::aws:policy/ReadOnlyAccess
aws iam get-policy-version --policy-arn arn:aws:iam::aws:policy/ReadOnlyAccess --version-id <DISCOVERED_DEFAULT_VERSION_ID>
# additional policies on the role: discovered ARN+DefaultVersionId only
aws iam get-policy --policy-arn <DISCOVERED_ATTACHED_ARN>
aws iam get-policy-version --policy-arn <DISCOVERED_ATTACHED_ARN> --version-id <DISCOVERED_DEFAULT_VERSION_ID>
# re-read ReadOnlyAccess GetPolicy to detect default-version drift during capture
```

Version IDを`v1`などと推測しない。Managed policy再照合はPolicy ARN単位、VersionId単位、両時点のGetPolicy SHAで表す。ページネーション未完を成功と扱わない。

## 対象Regionの確定

`ec2 describe-regions` は承認時のみ使用。`--all-regions` は広いscopeになるので勝手に使わない。結果とサービス提供Region一覧の差は調査範囲に残す。対象Regionは人間が明示したものだけを順番に処理。

## ECS: Role依存関係のみ

```text
aws ecs list-clusters --region <APPROVED_REGION>
aws ecs list-services --cluster <DISCOVERED_CLUSTER> --region <APPROVED_REGION>
aws ecs describe-services --cluster <DISCOVERED_CLUSTER> --services <DISCOVERED_SERVICE_ARNS> --region <APPROVED_REGION>
aws ecs list-tasks --cluster <DISCOVERED_CLUSTER> --region <APPROVED_REGION>
aws ecs describe-tasks --cluster <DISCOVERED_CLUSTER> --tasks <DISCOVERED_TASK_ARNS> --region <APPROVED_REGION>
aws ecs describe-task-definition --task-definition <DISCOVERED_TASK_DEFINITION_ARN> --region <APPROVED_REGION> --query 'taskDefinition.{taskDefinitionArn:taskDefinitionArn,taskRoleArn:taskRoleArn,executionRoleArn:executionRoleArn,revision:revision,status:status}'
```

`describe-task-definition` は戻り値に平文 `containerDefinitions.environment[].value` を含み得る。**CLIの`--query`はローカルの保存/表示を最小化するが、APIが機微のレスポンスを返さない保証ではない。**この操作自体に人間の明示承認が必要。使えるなら厳密なローカルフィルタのみに渡す。未使用定義と過去Revisionの網羅性を保証しない。

## S3: Bucket / Access Point

```text
aws s3api list-buckets
aws s3api get-bucket-location --bucket <DISCOVERED_BUCKET> --expected-bucket-owner 168975706502
aws s3api get-bucket-policy --bucket <DISCOVERED_BUCKET> --expected-bucket-owner 168975706502
aws s3api get-bucket-acl --bucket <DISCOVERED_BUCKET> --expected-bucket-owner 168975706502
aws s3api get-bucket-ownership-controls --bucket <DISCOVERED_BUCKET> --expected-bucket-owner 168975706502
aws s3control list-access-points --account-id 168975706502 --region <APPROVED_REGION>
aws s3control get-access-point-policy --account-id 168975706502 --name <DISCOVERED_AP_NAME> --region <APPROVED_REGION>
# Object Lambda / Multi-Region / Directory-bucket-specific discovery: require separate explicit scope approval
```

`NoSuchBucketPolicy` は `NO_POLICY`、`AccessDenied` は `UNKNOWN_ACCESS_DENIED`。S3オブジェクトデータ/API object get/listは本作業外。S3 Access Point一覧が0でもMRAPやObject Lambda、ACL等の未調査経路は残る。

## KMS / Lambda / Secrets Manager

```text
aws kms list-keys --region <APPROVED_REGION>
aws kms get-key-policy --key-id <DISCOVERED_KEY_ID> --policy-name default --region <APPROVED_REGION>
aws kms list-grants --key-id <DISCOVERED_KEY_ID> --region <APPROVED_REGION>
# Prefer human-approved known Function ARNs. Do not execute ListFunctions by default.
aws lambda get-policy --function-name <HUMAN_APPROVED_FUNCTION_ARN> --region <APPROVED_REGION>
# Exception only: list-functions may expose Environment.Variables in the response.
# aws lambda list-functions --region <APPROVED_REGION> --query 'Functions[].{FunctionArn:FunctionArn}' 
aws secretsmanager list-secrets --region <APPROVED_REGION>
aws secretsmanager get-resource-policy --secret-id <DISCOVERED_SECRET_ARN> --region <APPROVED_REGION>
```

KMS key/grantやresource policyにあるprincipal/Conditionにセンシティブな内部構成が含まれ得る。**原本保管はRestricted tier。Lambda ListFunctionsもEnvironment.Variablesが返る可能性があるため例外承認が必要。例外時も生レスポンス保存・表示不可。GetSecretValue / Decrypt / Invoke / GetFunctionConfigurationは禁止。**

## 広範なポリシー評価の限界

- API参照はread-onlyでも CloudTrail 記録・API料金・スロットルなどの影響を伴い得る。事前の件数見積りと実行速度制限、再試行上限は人間と決める。
- service/Region/Account間の権限制約とAWS Organizations SCP/RCPは別経路。権限不足や未列挙ならUNKNOWN。
- ポリシーを取得しただけでは適用結果・条件値・Principalリソースの有効性、将来のdrift、セッションポリシーの実装強制を証明できない。
