# SEC04-RESOURCE / F-004 Evidence Acquisition — Full Work Contract

## 1. 規範・固定条件

本作業は 2026-10-14 Broker Security Contract **Draft** の B-01、B-02、B-05、B-10、T-01、T-06、T-10 と、R2のFinding F-004 / F-006 を調査対象とする。Draftは未承認であり、ここから最終設計や権限追加を推論しない。

- 固定 Repo Commit: `05f4b92e7ff2de76dc79cf8d5dc9f563a03af209`。GitHubの現在のHEADを代入しない。
- Account: `168975706502`、Role ARN: `arn:aws:iam::168975706502:role/scs2-stg-ecs-tasks-role`、RoleId: `AROASOV54VGDAC4S2255I` は**期待値**であり、実測前に「一致」と記載しない。
- Source: 既存の `aws login` プロファイル `aws-mcp-readonly`（管理者資格情報があり得る）。証跡収集のための最小限のアクセスに限定し、資格情報・ログインキャッシュをエージェントに表示/転送させない。
- `ReadOnlyAccess` の検証対象 ARN: `arn:aws:iam::aws:policy/ReadOnlyAccess`。**AWS管理ポリシーにReadOnlyの名があっても安全性を仮定しない**。
- R2保守的21アクションは未承認であり、STSポリシーとして適用しない。
- 比較すべき既存SAR snapshot: 2026-10-15の14サービスの原本、独立検証済み。全AWSを網羅するものではない。

## 2. 権限とセーフガード（例外なし）

**許可候補:** 明示されたAWS IAM/STS identity inspection、AWS管理Policy取得、指定ロールとその信頼/インライン/アタッチPolicy取得、ECS利用参照、対象サービスのResource Policy/Grant/ACLの安全な参照のみ。AWS CLI/SDK呼出しは「サービス+オペレーション+対象+Region+出力項目」の事前人間承認ごとに実施。

**禁止:** `AssumeRole*`, `GetSessionToken`, `GetFederationToken`, `aws login` の再設定・資格情報エクスポート、IAM Create/Update/Delete/Attach/Detach、STSクレデンシャルの発行、新ロール/ポリシー、ECS RunTask/Update/ExecuteCommand、S3 Put/Delete/Copy、KMS Decrypt/GenerateDataKey、SecretsManager GetSecretValue/BatchGetSecretValue、SSM GetParameter(s) with decryption、Lambda Invoke、CloudFormation更新、EC2変更、AWS Organizations変更、実リソースの変化を伴うAPI、IAMシミュレーション・DryRunによる負試験（本作業では実施しない）、本番MCP起動、`git push` / PR / Commit、`docker compose up` 等によるデプロイ。`--debug`, shell `set -x`, credential cacheのcat/cp/tar、出力にアクセスキー/トークン/シークレットを含めることを禁止する。

- `sts:GetCallerIdentity` は現在の**発行済みログイン主体を同定する読み取り**としてのみ、操作オーナーが許可した場合に限り使用可。STSセッション**発行**と明確に区別する。
- エージェントによるアカウント/ロール切替、`--profile` の自動フォールバック、AWSリージョンの勝手な拡大は禁止。
- `AccessDenied` / `NoSuch*` / `UnsupportedRegion` / timeout はそれぞれ明示的に記録する。例外を握り潰さない。
- SNS/SQS、S3 Object Lambda、MRAP、Directory Bucket、ECR、EventBridge、SSM、CloudWatch Logsなど**追加のpolicy pathwayは存在し得る**。対象サービス未承認のまま勝手に照会しない。対象外であればギャップとする。

## 3. 調査フェーズと停止条件

### P0 — 事前審査・実行環境記録

- 操作担当・承認者・採取目的・対象AWSアカウント・リージョン・サービス・開始/終了時刻・AWS CLIバージョン・スクリプトSHA-256を記録。
- Output はローカル制限領域（`umask 077`, ディレクトリ `0700`, ファイル `0600`）、端末・リモートAIチャットには原本ポリシーや資格情報を表示しない。
- 使用実体のAWS CLIパス/バージョンとcredential providerを**秘密値を出さず**識別。ECS本番コンテナを起動しない。

### P1 — 本人確認・Role identity

- `sts:GetCallerIdentity` (事前承認された場合) で**現在のsource主体**の `Account`, `Arn`, `UserId` のみを記録。`Account` が期待と違えば停止。Source principalは承認済み基準値がなければ `SOURCE_PRINCIPAL_BASELINE_PENDING`。
- `iam:GetRole` で Role.Arn/RoleId/MaxSessionDuration/Path/PermissionsBoundary/AssumeRolePolicyDocumentをローカル取得。RoleId/Arn不一致は**即停止**。Role名の一致のみでは不十分。
- Trust PolicyのPrincipal/Condition/ExternalIdに機微情報がある可能性を想定し、原本はRestricted tier、共有用にはRoleId・Principal類型・一致結果とハッシュを残す。Trust policyの既存ECSサービス主体・source主体への影響を評価するが変更はしない。

### P2 — Managed policy / role permission snapshot (F-004)

- `iam:GetPolicy` で ReadOnlyAccess DefaultVersionId, 更新/作成日時を採取。
- `iam:GetPolicyVersion` で該当版の完全な `Document` と `IsDefaultVersion` を採取。**取得したJSON原本バイトのSHA-256と、JSON文書の正規化ハッシュを別々に記録**。比較正規化は UTF-8 / `json.dumps(sort_keys=True,separators=(',',':'),ensure_ascii=False)` 等、アルゴリズム名と実装を明示。**AWSサービスによりURLエンコード/SDKでのデコード表現が変わる場合はrawとsemanticを混同しない**。
- 再度 `iam:GetPolicy` を呼び `DefaultVersionId` が採取前後で一致するかを照合。不一致なら `DRIFT_DURING_CAPTURE` とし、古い版を承認基準にしない。
- `iam:ListAttachedRolePolicies`, `iam:ListRolePolicies`, `iam:GetRolePolicy`, 該当する managed policyの `GetPolicy` / `GetPolicyVersion` を対象にRoleのIdentity-Based Policiesを固定。IAM認可の完全な評価にはRole/Org/Resource/Session各ポリシーが別途必要。現時点で `AdministratorAccess` が付いていると推定しない。
- **ReadOnlyAccess現在版と「Owner承認済み」基準版の比較**は、承認済みbaselineがなければ `NO_APPROVED_BASELINE` であり `DRIFT_VERIFIED` / `SAFE` としない。

### P3 — 共有ECSワークロードの参照

- 許可されたRegionごとにECS Cluster/Service/Task Definition参照を収集し、候補ロールが `taskRoleArn` / `executionRoleArn` として使われるかを同定。必要なら稼働TaskとService外Taskも対象にする。
- `ecs:DescribeTaskDefinition` のレスポンスは**環境変数の生値を含み得る**ため、通常の原本保存やAI転送を禁止。ローカルプロセスで `taskDefinitionArn`, `taskRoleArn`, `executionRoleArn`, `status`, `revision` 等のホワイトリスト字段だけ抜き出す。生レスポンスの共有は禁止。タスク定義のSecret ARNや平文環境変数は出さない。
- IAM側のRole使用、ECSサービス・タスクの参照のみを根拠とし、**すべての本番ECSの非干渉や将来の無影響を証明しない**。所有者による運用依存関係の承認が必要。

### P4 — Resource Policy / direct session exception inventory (F-006)

- 必須Tier 1（対象Regionに応じて）：S3 bucket policies / bucket ACL / Ownership Controls / Access Point policies、KMS key policies+grants、Lambda resource policies、Secrets Manager resource policies。いずれも**秘密ペイロードに触れない**。
- S3: `list-buckets` で**新鮮な母数**、各bucket `get-bucket-policy --expected-bucket-owner` で policy有無、Region取得を記録。前回「162 buckets、73 policies」は履歴証跡であり現在の全数として採用しない。Access Point / Object Lambda / Multi-Region Access Point / Directory Bucket / S3 ACL の未調査経路を明記。必要なAPIの実行にOwner承認がなければ未調査。
- KMS: `list-keys`（承認Region）、`get-key-policy`, `list-grants` 等。Principal=role ARN, source role ID, session principalなどを分析し、キーポリシーとgrantsを別の許可経路として扱う。外部アカウントのキーや参照不可のキーは `UNKNOWN`。
- Lambda: `get-policy` は既知の対象Function ARNに限定する。`list-functions` は**Environment.Variablesの値が返る場合がある**ため通常実行しない。網羅性確保に不可欠なら人間の追加承認とローカル出力ホワイトリストフィルタを必須とし、生レスポンスを保存/表示/転送しない。それでもAPIレスポンス受信自体の機微リスクが残る。`get-function-configuration` は実行しない。未承認なら `LAMBDA_INVENTORY_NOT_COVERED`。
- Secrets Manager: `list-secrets` と `get-resource-policy`。`GetSecretValue`, `BatchGetSecretValue` は禁止。Secret名/ARN自体も業務機密になり得るためローカル限定。
- AWS OrganizationsのSCP/RCP、クロスアカウント資源、SQS/SNS/EventBridge/ECR等の他のResource Policy、bucket object ACL等、取得に必要な操作が未許可なら**必ず境界外と明記**。未調査を `NO_GRANTS` とみなさない。
- Action とPrincipalの評価では、直接role session ARN、`Principal:'*'` + `aws:PrincipalArn` 条件、ARN文字列/RoleId差、`NotPrincipal`, `NotAction`, 条件キー/タグ、クロスアカウント、サービス主体を個別に見る。**明示的Denyと暗黙的Denyを別々に評価**。リソースベースでセッションPrincipalに直接Allowする場合、session-policyの暗黙的Denyでは制約できない経路がある。AWS公式評価ロジックに沿ってリスクを記録。

### P5 — Coverage / Finding / owner handoff

- `03_EVIDENCE_REQUIREMENTS.csv` の各要件を `VERIFIED_LOCAL_INTEGRITY` / `CAPTURED_PENDING_REVIEW` / `PARTIAL` / `DENIED` / `UNKNOWN` / `NOT_APPLICABLE` / `NOT_EXECUTED` で埋める。
- **API成功率、取得対象/発見対象の母数、全Regionの母数、ページネーション完了、有効/未対応サービス、リトライ、失敗理由**を示す。`NoSuchBucketPolicy` と `AccessDenied` を区別。Region別のcoverageと各リソース件数を出す。
- 各Statementについて `Effect`, `Principal`類型, `Action/NotAction`, `Resource/NotResource`, `Condition` の対応、Candidate role/sessionへの到達可能性、直接書込許可の可能性、強制Denyとの関係を**推定と証拠を分けて**記述。
- 出力はローカルRestricted原本、共有安全サマリー、SHA256SUMS、Manifest、Capture/Errors log、Risk Matrix、Finding Disposition、Owner Decision Questions。Finding正式CLOSEやGate GOを宣言しない。

## 4. 受入基準と非達成条件

- 全てのAWS呼び出しが事前承認されたallowlist内であり、**無変更・無STS発行**が監査可能。
- `Account`/`RoleArn`/`RoleId` とPolicy版固定に必要な元証跡が揃う（不一致なら直ちに中断）。
- 少なくともRole identity, ReadOnlyAccess, existing policy, S3/KMS/Lambda/SecretsManagerを対象に、**実際に取得できた範囲を定量化**。未許可やアクセス拒否でもその事実が正確なら証跡取得として評価可能だが `RESOURCE_SAFE` とは判定できない。
- Agent判断による`CLOSED`, `SAFE`, `GO`, `AUTHORIZED_FOR_IMPLEMENTATION`は一切禁止。Ownerの採用承認と別のChatGPTの独立レビューに引き渡す。

## 5. 参考一次資料

- IAM評価とsession principal: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic_policy-eval-denyallow.html
- IAM Principal: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html
- IAM evaluation types: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- ECS task definition return fields: https://docs.aws.amazon.com/AmazonECS/latest/APIReference/API_DescribeTaskDefinition.html
- S3 Access Points: https://docs.aws.amazon.com/cli/latest/reference/s3control/list-access-points.html
- KMS policy: https://docs.aws.amazon.com/kms/latest/APIReference/API_GetKeyPolicy.html
- Secret resource policy: https://docs.aws.amazon.com/cli/latest/reference/secretsmanager/get-resource-policy.html
