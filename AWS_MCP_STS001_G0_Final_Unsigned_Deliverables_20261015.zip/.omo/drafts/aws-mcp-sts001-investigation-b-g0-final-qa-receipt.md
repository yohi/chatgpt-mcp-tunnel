# Investigation B — G0最終候補のオフライン準備QA記録

## 1. 対象と限界

対象は同じディレクトリの次の3文書と本記録。これは署名対象の外側にあるplanning QAであり、運用case/auditではない。

- `aws-mcp-sts001-investigation-b-g0-final-decision-record-unsigned.md`
- `aws-mcp-sts001-investigation-b-g0-lifecycle-schedule-unsigned.md`
- `aws-mcp-sts001-investigation-b-g0-finalization-review-handoff.md`

納品バイト列のhashは [SHA256SUMS](aws-mcp-sts001-investigation-b-g0-final-SHA256SUMS) に記載する。
本書に自身のhashを埋め込まない。checksums自身はchecksumsの対象外。
本記録は人間の承認、本人性・権限・保存先・実行隔離・削除/保持の実証ではない。

## 2. 入力検証の実行記録

repository rootから次を実行した。

```bash
unzip -l AWS_MCP_STS001_G0_Final_Unsigned_Record_Handoff_20261015.zip
unzip -t AWS_MCP_STS001_G0_Final_Unsigned_Record_Handoff_20261015.zip
sha256sum AWS_MCP_STS001_G0_Final_Unsigned_Record_Handoff_20261015.zip
```

抽出前に一覧10件の名前を確認しCRCを検査した。planning作業用の
`STS001_G0_FINAL_OFFLINE_20261015/input/` に受領文書だけを展開した。
これは取得用SEC04_RESOURCE ZIPのP0展開でも、提案された運用保存先の作成でもない。
その後、Python標準ライブラリで全memberの型/安全経路/重複/展開量を検査し、全抽出バイト列をZIPと照合した。
安全型のプログラム検査を展開前に実施したとは主張しない。検査結果は期待regular member10件のみ。

展開先inputを作業ディレクトリとして `sha256sum -c SHA256SUMS` と
`sha256sum reference/*.md` を実行し、内部9件と参照6件を照合した。
契約の固定hashは5件、static reviewの6件目は実計算して内部manifestと比較した。

| 検査 | 実行結果 |
| --- | --- |
| ZIP CRC | 10/10、`unzip -t` exit 0、`zipfile.testzip()` は `None` |
| ZIP member安全性 | 期待10件、重複/absolute/parent traversal/backslash/symlink/deviceなし、regular fileのみ |
| ZIP展開量 | 144973 bytes、期待値一致 |
| 内部SHA256SUMS | 9/9一致、自己参照なし、coverage一致 |
| 抽出文書とZIP内原本 | 10/10バイト一致 |
| 契約に固定された原本hash | P/D/C/G/Hすべて一致 |
| static review原本hash | `2a1ce704f4e215c31dc437d38703d9ab5c4cf86d7062027edbe334f5b702279b` |
| ZIP全体計算hash | `fc0dd28b9872ab8738f6b7790377a880168a7d5ad23643e1d2b1516079ac4cd1` |
| 発行者の外部認証 | `NOT_ESTABLISHED`、信頼済み外部期待hash/署名は未提供 |
| GitHub現況・原本再取得 | `NOT_EXECUTED`。引き継ぎに記録されたHEADを現況と認定しない |
| AWS/P0/保存先実証/人間承認 | `NOT_EXECUTED` / `NOT_VERIFIED` |

作業契約3文書と参照6文書を全文確認した。R1 plan 1009行、decision 100行、change 115行、
G0 packet 321行、旧handoff 148行、static reviewの既存判定と補完注意を確認した。
旧原本内の相対リンクには元repositoryのfilenameが残っている。原本は改変せず、今回の候補からの参照は同梱名へ結合した。

## 3. 成果物検証の再現コード

次のコードをPython 3標準ライブラリだけで実行する。作業ディレクトリはrepository root。
fileの作成/削除、ネットワーク、process環境、資格情報へアクセスしない。
署名・権限の意味的検証は行わず、未確定であることと文書整合性を検査する。

```python
import hashlib
import json
import pathlib
import re
import stat
import zipfile

base = pathlib.Path('.omo/drafts')
stem = 'aws-mcp-sts001-investigation-b-g0-'
names = [stem + suffix for suffix in (
    'final-decision-record-unsigned.md',
    'lifecycle-schedule-unsigned.md',
    'finalization-review-handoff.md',
    'final-qa-receipt.md',
)]
paths = [base / name for name in names]
texts = [path.read_text(encoding='utf-8') for path in paths]
record, lifecycle, handoff = texts[:3]
source = pathlib.Path('STS001_G0_FINAL_OFFLINE_20261015/input')
zip_path = pathlib.Path('AWS_MCP_STS001_G0_Final_Unsigned_Record_Handoff_20261015.zip')
assert hashlib.sha256(zip_path.read_bytes()).hexdigest() == 'fc0dd28b9872ab8738f6b7790377a880168a7d5ad23643e1d2b1516079ac4cd1'
expected = {'00_AGENT_PROMPT.md', '01_HUMAN_SELECTIONS.md', 'README_FIRST.md', 'SHA256SUMS'}
fixed = {
    'R1_EXECUTION_PLAN.md': '15a9adad32011a6f1f660875d877c25092afc8eaa38a8c6a4b2486c1c451b9b1',
    'R1_DECISION_RECORD.md': 'a0d9d175e1c280bee1eab856783bf356c5cde33dd2383fc591395f68c79771c6',
    'R1_CHANGE_REGISTER.md': '88b46081efe54c40175b610ec98019642e941acd543960b05d4376a3fa3bf2c8',
    'G0_APPROVAL_PACKET_UNSIGNED.md': '7a47ddaa5c8d9109d65d3ef59e8090a7c2fc9428a646913cca819e4f50026d60',
    'G0_INDEPENDENT_REVIEW_HANDOFF.md': 'ee05fa9c9d2ac43506f6be266e2b18da82b2c2ffaff9e11baa0c84bf061643d7',
    'G0_INDEPENDENT_STATIC_REVIEW.md': '2a1ce704f4e215c31dc437d38703d9ab5c4cf86d7062027edbe334f5b702279b',
}
expected |= {'reference/' + name for name in fixed}
with zipfile.ZipFile(zip_path) as archive:
    members = archive.infolist()
    assert len(members) == len(set(archive.namelist())) == 10
    assert set(archive.namelist()) == expected
    assert sum(item.file_size for item in members) == 144973
    assert archive.testzip() is None
    for item in members:
        member = pathlib.PurePosixPath(item.filename)
        assert not member.is_absolute() and '..' not in member.parts
        assert '\\' not in item.filename and not item.is_dir()
        assert stat.S_IFMT(item.external_attr >> 16) in (0, stat.S_IFREG)
        assert (source / item.filename).read_bytes() == archive.read(item.filename)
    entries = archive.read('SHA256SUMS').decode().splitlines()
    covered = []
    for entry in entries:
        digest, name = entry.split(maxsplit=1)
        name = name.lstrip('*')
        covered.append(name)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
    assert len(covered) == len(set(covered)) == 9
    assert set(covered) == expected - {'SHA256SUMS'}
for name, digest in fixed.items():
    assert hashlib.sha256((source / 'reference' / name).read_bytes()).hexdigest() == digest
print('PASS input: CRC 10/10, manifest 9/9, fixed/reference hashes 6/6, extracted bytes 10/10')

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result

blocks = [block for text in texts[:3] for block in re.findall(r'```json\n(.*?)\n```', text, re.S)]
assert len(blocks) == 1
approval = json.loads(blocks[0], object_pairs_hook=unique_object)
assert approval['decision'] == 'UNDECIDED'
assert approval['approval_state'] == 'APPROVAL_PENDING'
assert approval['signature'] == ''
assert approval['aws_api_count'] == approval['aws_request_budget'] == 0
assert approval['aws_api_allowlist'] == approval['aws_region_endpoint_grants'] == []
assert approval['approved_at_utc'] is approval['approval_expires_utc'] is None
assert approval['deletion_grant'] == 'NONE_GRANTED'
assert approval['credential_provider_resolution'] == approval['source_profile_fallback'] == 'PROHIBITED'
for field in ('scope_id', 'scope_revision', 'scope_digest', 'operator_verified_id',
              'approver_verified_id', 'executor_verified_id', 'exact_input_paths_and_digests',
              'exact_output_paths_fields_and_recipients', 'tool_runtime_config_ids_versions_digests_and_invocations',
              'independently_attributable_approval_event', 'final_immutable_record_digest_binding',
              'canonical_case_root_and_storage_attestation', 'final_lifecycle_revision_digest_and_authority_event'):
    assert 'PENDING' in approval[field], field
for od in ('OD-01', 'OD-02', 'OD-08', 'OD-09', 'OD-10'):
    assert od in record and od in handoff
statuses = ('DRAFT_UNSIGNED_NOT_AUTHORIZED', 'PLAN_PREPARED_PENDING_EXECUTION_APPROVAL',
            'G0_NOT_AUTHORIZED', 'P0_NOT_EXECUTED',
            'G1-G5 / G1b / G5-release NOT_AUTHORIZED', 'Gate STS-001 NOT VERIFIED')
for text in texts[:3]:
    assert all(status in text for status in statuses)
print('PASS JSON: syntax, unique keys, undecided/unsigned/pending fields, AWS budget 0; status/gate separation')

classes = re.findall(r'^### C(\d{2}) — (.*?)\n(.*?)(?=^### |^## |\Z)', lifecycle, re.M | re.S)
class_names = ['Restricted raw originals', 'Aliases / mappings / salts',
               'Transient / input / filter copies', 'QA records', 'Audit records',
               'Share-candidate copies', 'Local approved-share copies',
               'External distribution copies', 'Approval records', 'Deletion receipts']
durations = [30, 30, 7, 90, 180, 30, None, None, 180, 180]
assert len(classes) == 10
for index, ((number, name, body), expected_name, duration) in enumerate(zip(classes, class_names, durations), 1):
    assert int(number) == index and name == expected_name
    for field in ('approved_anchor_event_id/utc', 'human_approved_use/event',
                  'review_due_utc', 'escalate_at_utc', 'retention_expires_utc',
                  'custodian_verified_id/backup_verified_id', 'exact_case_owned_scope/manifest',
                  'standing_deletion_instruction/authority/event', 'legal_hold_authority/process',
                  'residual_copies_snapshots_disposition', 'reviewer_access_cutoff_utc'):
        assert field in body, (number, field)
    if duration is None:
        assert 'NOT_CREATED_NO_WRITE' in body and 'PENDING_NOT_CREATED' in body
        assert not re.search(r'\d+ days', body)
    else:
        assert re.findall(r'\*\*(\d+) days\*\*', body) == [str(duration)]
        assert 'NONE_GRANTED' in body and 'proposed_anchor' in body and 'proposed_use' in body
        assert body.count('`PENDING`') >= 17
assert 'RETENTION_BREACH' in lifecycle and 'RETENTION_EXCEPTION_LEGAL_HOLD' in lifecycle
assert 'reviewer_verdict=UNASSIGNED' in handoff
assert all(verdict in handoff for verdict in ('ACCEPTED_FOR_HUMAN_G0_DECISION_CONSIDERATION', 'REVIEW_REQUIRED', 'BLOCKED_REFERENCE_INTEGRITY'))
print('PASS lifecycle: 10 distinct classes, exact duration/no-write policies, per-class fields and pending dates/authority')

plan_lines = (source / 'reference/R1_EXECUTION_PLAN.md').read_text().splitlines()
checks = [(169, 217, 'Operator consent alone is'), (225, 253, 'sanitized'),
          (412, 449, 'ACTUAL selected'), (455, 477, 'Before ANY operational case-owned file write'),
          (538, 585, 'RETENTION_BREACH'), (668, 675, 'After P1')]
assert len(plan_lines) == 1009
for first, last, phrase in checks:
    assert 1 <= first <= last <= len(plan_lines)
    assert phrase in '\n'.join(plan_lines[first - 1:last])
for text in texts[:3]:
    for first, last in re.findall(r'\bL(\d+)(?:-(\d+))?', text):
        assert 1 <= int(first) <= int(last or first) <= 1009
for text in texts:
    assert text.endswith('\n') and not any(line.rstrip() != line for line in text.splitlines())
    assert len(re.findall(r'^# ', text, re.M)) == 1
    assert len(re.findall(r'^```', text, re.M)) % 2 == 0
    for link in re.findall(r'\]\(([^)]+)\)', text):
        assert not link.startswith(('http:', 'https:')), ('unexpected remote link', link)
        assert (base / link).is_file(), ('broken link', link)
    for character in text:
        value = ord(character)
        assert not (0x1100 <= value <= 0x11ff or 0x3130 <= value <= 0x318f or 0xac00 <= value <= 0xd7af)
        if 0x3400 <= value <= 0x9fff or 0x20000 <= value <= 0x323af:
            character.encode('iso2022_jp')
for text in texts[:3]:
    assert not re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', text)
    assert not re.search(r'/(?:home|Users)/|arn:aws[^\s`]*|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b|\b[0-9]{12}\b|\bAROA[A-Z0-9]{12,}\b', text)
    assert not re.search(r'-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:aws_secret_access_key|aws_session_token)\s*[=:]\s*[^\s]+', text, re.I)
print('PASS source line anchors, all local links, Markdown structure subset, Japanese Han repertoire/Hangul exclusion, privacy-pattern checks')

manifest_path = base / (stem + 'final-SHA256SUMS')
manifest = manifest_path.read_text().splitlines()
assert len(manifest) == 4
seen = []
for entry in manifest:
    digest, name = entry.split(maxsplit=1)
    seen.append(name)
    assert name in names
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == digest
assert len(set(seen)) == 4 and set(seen) == set(names)
print('PASS final SHA256SUMS 4/4; no document self-hash; no manifest self-entry')
print('NO OPERATIONAL VALIDATION; independent reviewer verdict UNASSIGNED; G0_NOT_AUTHORIZED; P0_NOT_EXECUTED; Gate STS-001 NOT VERIFIED')
```

実行コマンド（同じファイルから上記の固定コードを取り出す。運用入力のコードは実行しない）:

```bash
python3 -c 'import pathlib,re; p=pathlib.Path(".omo/drafts/aws-mcp-sts001-investigation-b-g0-final-qa-receipt.md"); code=re.findall(r"```python\n(.*?)\n```",p.read_text(),re.S); assert len(code)==1; exec(compile(code[0],"offline-document-qa","exec"))'
```

追加の標準checksumコマンドは `.omo/drafts/` を作業ディレクトリとして
`sha256sum -c aws-mcp-sts001-investigation-b-g0-final-SHA256SUMS`。
source行参照は内容の手動確認に加えて上記の境界・主要引用検査を行う。
全ての意味的主張がregexで検証されるわけではない。

## 4. QA結果と未実施事項

- 成果物QA: 上記再現コードを実行しexit 0。input、JSON/status、10クラス、出典行/link/文字/privacy、
  最終SHA256SUMSの5検査群すべてPASS。結果記入後も再hashと最終実行を行い、納品バイト列へ結合する。
- 著者による文書照合では正式なblocking document findingを新規起票していない。
  OI-01〜OI-12の人間判断/実証は未解決であり、G0の実行阻害条件は解消していない。
- Markdownlint CLI: `command -v markdownlint-cli2` は利用可能な実行pathを返さず。
  full markdownlintは `NOT_EXECUTED_TOOL_UNAVAILABLE`。上記構造subset検査を代替として明記する。
- 秘密/ARN/account/source principal/private home path/日本語文字の静的検査は対象3成果物に対するもの。
  機密性保証ではない。氏名や行政的metadataの最終配布適否は人間確認を要する。
- 別contextの著者側reader testを実施。6問の理解確認で未許可/未確定と10方針を読み取れた。
  P0を可能にするG0イベントとcase前の既存承認経路の関係を明文化して補足した。
  これは正式な独立レビューではなく、今回候補の判定は `UNASSIGNED` のまま。
- 署名/人間承認、保存先実証、P0 fixture、source/request-path実証、AWS検証は全て未実施。
- 次の人間判断は引き継ぎOI-01〜OI-12とG0最終候補section 3/7に記載する。
- `G0_NOT_AUTHORIZED`、`P0_NOT_EXECUTED`、`Gate STS-001 NOT VERIFIED` を維持して停止する。
