# AWS MCP STS-001 Investigation B — G0 Document-Only Pull Request Agent Contract

**Prepared:** 2026-10-15 JST  
**Role:** GitHub documentation integration agent. Not a G0 approver, P0 executor, Requirements Owner, credential custodian, or independent reviewer.

## 0. Outcome / strict scope

Create **one documentation-only pull request**, targeting `feat/aws-broad-iam-read-api-tools`, to integrate two existing *unsigned* G0 preparation documents into `yohi/chatgpt-mcp-tunnel`. Do not merge it. This request authorizes GitHub writes **only** for creating the isolated documentation branch, committing the exact two reviewed Markdown files and opening that PR, plus the PR description/review request. It does **not** authorize G0, P0, AWS access, deletion, baseline changes, or code implementation.

The prior G0 independent-review handoff says `No GitHub writes` because that file was a contract for its earlier **static reviewer**. The current instruction supersedes that sentence solely for this distinct **documentation PR integrator** role; every AWS/secret/approval restriction continues to apply.

## 1. Immutable reference identities

- Repo: `yohi/chatgpt-mcp-tunnel` (**public** at the time of preparation; reverify before writing).
- Base branch: `feat/aws-broad-iam-read-api-tools` (NOT `master`; NOT `feat/aws-board-...`).
- Expected base HEAD: `9b6b1bca6ee089b1e1a10bcfc5139eb7bf1f9843` (PR #11 merged into this branch). Verify it freshly. If it has moved, STOP with `BLOCKED_BASE_DRIFT` and show the new SHA/diff; do not silently rebase, overwrite, or reset. Never confuse this integration HEAD with the historical code reference commit.
- Historical fixed code reference: `05f4b92e7ff2de76dc79cf8d5dc9f563a03af209` (**reference only**, not the parent for this PR).
- R1 plan SHA-256: `15a9adad32011a6f1f660875d877c25092afc8eaa38a8c6a4b2486c1c451b9b1`.
- R1 decision record SHA-256: `a0d9d175e1c280bee1eab856783bf356c5cde33dd2383fc591395f68c79771c6`.
- R1 change record SHA-256: `88b46081efe54c40175b610ec98019642e941acd543960b05d4376a3fa3bf2c8`.
- G0 unsigned packet SHA-256: `7a47ddaa5c8d9109d65d3ef59e8090a7c2fc9428a646913cca819e4f50026d60`.
- G0 independent handoff SHA-256: `ee05fa9c9d2ac43506f6be266e2b18da82b2c2ffaff9e11baa0c84bf061643d7`.
- Independent G0 static review SHA-256: `2a1ce704f4e215c31dc437d38703d9ab5c4cf86d7062027edbe334f5b702279b`.
- Review verdict: `ACCEPTED_FOR_HUMAN_G0_DECISION_CONSIDERATION`; no formal blocking findings. **Neither this verdict nor PR review grants G0.**

Do not substitute the current `master`, merge new product code, modify the R1 baseline, or claim a new security assurance.

## 2. Input ZIP and integrity prerequisite

The accompanying `AWS_MCP_STS001_G0_Document_PR_Handoff_20261015.zip` contains:

- `README_FIRST.md` — package map and precedence.
- `00_AGENT_PROMPT.md` — **this entire contract**, read in full.
- `deliverables/aws-mcp-sts001-investigation-b-g0-approval-packet-unsigned.md` — proposed committed file A.
- `deliverables/aws-mcp-sts001-investigation-b-g0-independent-review-handoff.md` — proposed committed file B.
- `reference/AWS_MCP_STS001_Investigation_B_G0_Independent_Static_Review_20261015.md` — independent document-only acceptance record; **review reference, not a third commit target**.
- `reference/aws-mcp-sts001-investigation-b-R1-plan.md`, `reference/aws-mcp-sts001-investigation-b-R1-decision.md`, `reference/aws-mcp-sts001-investigation-b-r1-changes.md` — R1 source snapshots, **reference only**.
- `SHA256SUMS` — digest ledger for all eight substantive members.

Before PR creation: hash the ZIP as received, validate CRCs, expected member allowlist, path traversal/symlink exclusions, and verify `SHA256SUMS` for all members. Compare committed-target bytes against the two exact SHA-256 values above. If any mismatch or missing file: `BLOCKED_REFERENCE_INTEGRITY`, no GitHub writes. ZIP integrity does not prove publisher authenticity, human identity, or operational approval.

Read both deliverables fully. Read independent review and the R1 plan/decision/change records as needed for references. Independently compare live GitHub R1 P/D/C file bytes at the exact base commit against the stated R1 hashes. If the integration base is absent/unreadable or R1 hashes differ, STOP; do not reconstruct or patch originals.

## 3. Public-repository release check — mandatory before creating branch/PR

The repository is public. The packet refers to AWS Account/Role identities that also occur in existing R1 planning material. Do not assume this makes **all** new disclosure safe. Review both exact documents and proposed PR body for access keys, tokens, login/cache/provider values, secrets, personal contact information, private paths, sensitive endpoint/host data or any newly added confidential operational evidence. Do not paste raw AWS config, stderr, credentials, evidence originals, or other unapproved content into GitHub, PR comments, CI, attachments or agent context.

If there is any unresolved confidentiality/publication question, STOP as `BLOCKED_PUBLICATION_REVIEW`. Present the exact concern to the human; do not silently redact either file (redaction would invalidate the reviewed document hash) or create a public PR. Once a human authorizes a revised publication-ready document, it needs a fresh digest and, where material, another independent document review.

## 4. Exact GitHub change scope

Create a branch from the **verified base HEAD**, suggested name:
`docs/aws-mcp-sts001-investigation-b-g0-packet`

The only allowed added files are:

1. `.omo/drafts/aws-mcp-sts001-investigation-b-g0-approval-packet-unsigned.md` from the ZIP deliverable, byte-for-byte unchanged.
2. `.omo/drafts/aws-mcp-sts001-investigation-b-g0-independent-review-handoff.md` from the ZIP deliverable, byte-for-byte unchanged.

No edits to either file for style/line endings; do not populate signature fields, decide Owner Decisions, change `PENDING`, insert dates, or mark G0 as approved. Do not commit the ZIP, independent report, R1 reference snapshots, AWS artifacts, local paths, `.env`, any other `.omo` file, test/source code or review receipts.

Use GitHub tooling already available or ordinary approved Git authentication, without AWS credential access. Do not force push, bypass protections, modify unrelated branches, or alter `master`. If the branch already exists, verify its ancestry/content and prefer a fresh non-colliding docs branch rather than rewriting history.

## 5. Mandatory offline pre-PR checks

1. Verify local target SHA-256 equals the two immutable hashes in §1 **after** preparing the commit.
2. Confirm Git diff base...head shows exactly the two named Markdown paths, with `added` status and no deleted/modified product files. If files already exist or conflict, STOP and report `BLOCKED_SCOPE_COLLISION`.
3. Parse fenced JSON in both documents with Python 3 stdlib; confirm key states include `DRAFT_UNSIGNED_NOT_AUTHORIZED`, `UNDECIDED`, `APPROVAL_PENDING`, `G0_NOT_AUTHORIZED`, `P0_NOT_EXECUTED`, `Gate STS-001 NOT VERIFIED` and AWS budget/API count 0; no signatures or actual owner values filled.
4. Confirm references/relative link work, the ten lifecycle classes remain, OD-01/02/08/09/10 are present, and no accidentally executable AWS command is introduced by the PR.
5. No AWS probe, credential provider invocation, P0 fixture execution, operational case-root creation, product test, or network endpoint discovery. Only static document checks and GitHub reads/writes within this scope.

If any check fails, do not open PR. Supply precise failure, affected path/digest and required human action. Do not self-remediate by expanding scope.

## 6. PR metadata and handoff

Once all checks pass, push that isolated docs branch and create **one** PR:

- **Base:** `feat/aws-broad-iam-read-api-tools`.
- **Head:** `docs/aws-mcp-sts001-investigation-b-g0-packet` (or collision-free variant).
- **Title:** `docs: add unsigned AWS MCP STS-001 Investigation B G0 decision packet`.
- **Review status:** Ready for human document review; no auto-merge.

Suggested PR description structure:

```markdown
## Purpose
Add the unsigned Investigation B G0 decision packet and independent-review handoff for human consideration. Document-only change.

## Scope
- Add `.omo/drafts/aws-mcp-sts001-investigation-b-g0-approval-packet-unsigned.md`
- Add `.omo/drafts/aws-mcp-sts001-investigation-b-g0-independent-review-handoff.md`
- No product code, R1 baseline, IAM, AWS config, credentials, operational evidence or Broker changes

## Static independent document review
- Verdict: `ACCEPTED_FOR_HUMAN_G0_DECISION_CONSIDERATION`
- Findings: 0 formal blocking; human-completion note on per-class lifecycle fields
- Independent report SHA-256: `2a1ce704f4e215c31dc437d38703d9ab5c4cf86d7062027edbe334f5b702279b`
- Report is a separately supplied reference, **not a file in this PR**; do not invent a GitHub report link
- Packet SHA-256: `7a47ddaa5c8d9109d65d3ef59e8090a7c2fc9428a646913cca819e4f50026d60`
- Handoff SHA-256: `ee05fa9c9d2ac43506f6be266e2b18da82b2c2ffaff9e11baa0c84bf061643d7`

## Gates / non-authorization
`PLAN_PREPARED_PENDING_EXECUTION_APPROVAL`; `G0_NOT_AUTHORIZED`; `P0_NOT_EXECUTED`; `G1–G5/G1b/G5-release NOT_AUTHORIZED`; `Gate STS-001 NOT VERIFIED`.
This PR and any merge are **not** a G0 approval or AWS/P0/Broker authorization.

## Before any future G0 consent
Humans must resolve OD-01/02/08(initial)/09/10 with authenticated authority, final exact scope, selected metadata mode, case root/custody, per-class retention/standing deletion, digest-bound approval, and expiry. Full actual-mode provider/request-path proof remains a separate pre-G1 requirement.

## Verification
Record exact static checks executed, their results, and that no AWS/API/credential/P0 activity occurred.
```

Request human PR review, not G0 execution approval. Do not approve or merge your own PR. Do not submit a separate implementation PR.

## 7. Final answer from PR agent

Return the PR URL and number, base/head branches, base SHA and new commit SHA, exact two changed paths and hashes, GitHub diff/CI review status as observed, reviewer disposition **without promoting it into execution consent**, and list of checks actually run and those not run. Explicitly preserve:

```text
PLAN_PREPARED_PENDING_EXECUTION_APPROVAL
G0_NOT_AUTHORIZED
P0_NOT_EXECUTED
G1-G5 / G1b / G5-release NOT_AUTHORIZED
Gate STS-001 NOT VERIFIED
```

Stop immediately after creating the PR and reporting it. The next steps are human document review/merge and independently authenticated OD decisions; **never start P0 or AWS operations** on the strength of this prompt, commit, PR, review or merge.
