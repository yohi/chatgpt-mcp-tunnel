# AWS MCP STS-001 Investigation B — G0 Document PR Handoff

This handoff is **only** for creating a documentation-only PR into `feat/aws-broad-iam-read-api-tools` from its verified reference HEAD `9b6b1bca6ee089b1e1a10bcfc5139eb7bf1f9843`.

1. Verify ZIP member names/CRC/SHA256SUMS and the expected fixed document digests.
2. Read `00_AGENT_PROMPT.md` in full and follow it as the operative instruction for the *PR integration agent*.
3. Commit **only** the two files in `deliverables/` to their prescribed `.omo/drafts/` destination paths. Never treat the `reference/` files as a commit instruction.
4. The `reference/` review handoff's older 'no GitHub writes' prohibition governed an earlier *static reviewer*, not this new PR integration agent. The new permission is strictly two documentation files plus the PR; AWS, credential and execution restrictions remain absolute.
5. The repository is publicly visible: perform the mandatory publication review before creating a branch/PR. Any unresolved sensitivity means no GitHub write.
6. Reviewer outcome `ACCEPTED_FOR_HUMAN_G0_DECISION_CONSIDERATION` is **not** G0 approval. The final statuses remain NOT_AUTHORIZED/NOT_EXECUTED.

**Immutable digests and filenames** are specified inside `00_AGENT_PROMPT.md` and in `SHA256SUMS`. The package's own SHA-256 is provided in the final delivery message, not embedded here to avoid self-reference. No AWS environment, credential material, local case directory, executable patch, or signing material is included.
