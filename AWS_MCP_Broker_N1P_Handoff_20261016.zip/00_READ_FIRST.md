# READ FIRST — AWS MCP Broker Phase N1-P Handoff

このZIPは、**人間による正式採用の前の、未署名決裁準備専用**です。正式Requirementsの権威・採用イベントの証明ではありません。

1. 外側ZIPのSHA-256・CRC・パス・MANIFEST・SHA256SUMSを先に検証する。
2. `01_N1P_AGENT_WORK_CONTRACT.md` を**全文**読む。これが今回の完全な指示契約。
3. `sources/01_N1_Deliverables_20261016.zip` のSHA-256 `b26add50668cf2bdc7929513a7a8c1e3a2325b7c6d8e45e0ab9dd35ca67e0ef6` を確認し、その内部文書・原本コピーを独立に確認する。
4. `02_OWNER_HANDOFF_CONTEXT.md` は作業上の要約であり、N1原本より優先される権威ではない。
5. 出力は未署名資料に限定し、GitHub・AWS・Bitwarden・Dockerへの変更や本番動作を禁止する。

## ZIPの中身

- `01_N1P_AGENT_WORK_CONTRACT.md`: N1-Pの作業契約
- `02_OWNER_HANDOFF_CONTEXT.md`: 今回確定すべき判断と未実証Gate
- `sources/01_N1_Deliverables_20261016.zip`: N1調査報告6文書と47証拠ファイル、入れ子原本候補
- `MANIFEST.json` / `SHA256SUMS`: この引き継ぎパッケージの完全性検証

候補Option A採用意思は保持するが、Case Pの正式採用自体は未選択・未承認である。N2の開始条件、INT-003、G0、STS-001は満たされていない。
