# Owner handoff context — Proposed Case P, not an adoption event

## 現在の決裁可能性

提出されたB1/B2/B3とOption A R1本文はバイト同一性を再検算可能。ただし旧版の権威原本や承認証跡は未取得であり、Case Pは新しい将来時点の採用経路の**候補**である。以前の正式採用とみなさない。

## 既に決定方向がある事項

- Option A（REQ-009/REQ-046/AC-022）は以前に選択済み。N1-Pで再選択させず、**固定全文と署名・イベント・効力時刻の正当な結合**を準備する。
- 他方、R4追加22条項（REQ-050〜059、AC-025〜036）は全件未採用で、デフォルトはPENDING。省略せず個別処遇を準備する。

## 人間の未決事項

1. 正式Owner/Custodian/Design/Security承認者・独立性・私的な証明経路
2. Case Hを証明する原本・来歴があるか、Case Pを今後の新規採用として選択するか
3. B3 Q33〜Q40要約の新規現行規範としての扱い、REQ-025/INT-001/REQ-042の衝突と優先関係
4. Composition manifest・Revision・全文Digest・効力範囲と将来の失効規則
5. 完全なDesign、統合AC、Security Contractの権威と採否
6. R4追加22条項ごとの採用・延期・却下・改訂の最終処遇
7. 実際の認証済み正式承認イベントID、UTC時刻、発効時刻（決裁後に記入）

一部採用と全体Baseline確定・N2開始・I2本格実装は分ける。

## 特に維持する安全制約

- 1名が複数ロール/アカウントを使っても INT-003 の独立二者承認にはならない。
- FEAS-007-C/取得前内容保証が実証されるまでBitwarden Secret AdapterやToken配置・Secret取得を有効化しない。
- AWS長期キー流入の禁止、長期キーfallback禁止、秘密情報のAI・ログへの開示禁止を弱めない。
- 旧Security Contract Draftの特権Broker想定を新v1.1の正式仕様として昇格させない。

## N1基準

- Git fixed HEAD: `ac462699e0b1988eda63ea3d6dacfc2a030bb822`
- N1 input SHA-256: `b26add50668cf2bdc7929513a7a8c1e3a2325b7c6d8e45e0ab9dd35ca67e0ef6`
- NORMATIVE_BASELINE NOT_VERIFIED, INT-003 CRITICAL_OPEN, N2 NOT_STARTED, I2 BLOCKED, G0 NOT_AUTHORIZED, STS-001 NOT VERIFIED.
